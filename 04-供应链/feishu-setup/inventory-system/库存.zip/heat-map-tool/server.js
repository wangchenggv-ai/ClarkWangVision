/**
 * Ultra 车房库存热力图工具 - 服务端
 * 通过 lark-cli 子进程调用 Bitable API（自动使用 user token）
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');
const { execSync } = require('child_process');

const BASE_TOKEN = 'O1Zwbdcnva1kZEsRdgjcuaEZnfc';
const STOCK_TABLE = 'tblvYJw1LuXyaTeP';
const DISPATCH_TABLE = 'tblVqaFdATjb5jnq';
const PORT = 3456;

// ─── lark-cli 调用封装 ──────────────────────────────────
function larkCli(args, opts = {}) {
  const fmtFlag = opts.noFormat ? '' : ' --format json';
  const cmd = `lark-cli ${args} --as user${fmtFlag}`;
  try {
    const out = execSync(cmd, { encoding: 'utf-8', timeout: 30000, windowsHide: true, cwd: __dirname });
    try { return JSON.parse(out); } catch (_) { return { raw: out }; }
  } catch (e) {
    if (e.stderr) {
      try { return JSON.parse(e.stderr); } catch (_) {}
    }
    throw new Error(e.message.split('\n')[0]);
  }
}

function larkCliWithJson(args, jsonObj) {
  const tmpFile = `.tmp-${Date.now()}.json`;
  fs.writeFileSync(tmpFile, JSON.stringify(jsonObj), 'utf-8');
  try {
    return larkCli(`${args} --json @${tmpFile}`, { noFormat: true });
  } finally {
    try { fs.unlinkSync(tmpFile); } catch (_) {}
  }
}

// ─── 解析 lark-cli record-list 返回 ─────────────────────
function parseRecords(result) {
  const d = result.data;
  if (!d || !d.data) return [];
  const fields = d.fields;
  const records = [];
  for (let i = 0; i < d.data.length; i++) {
    const row = d.data[i];
    const rec = { record_id: d.record_id_list[i] };
    fields.forEach((f, j) => {
      let val = row[j];
      // 公式字段返回字符串，转数字
      if (typeof val === 'string' && !isNaN(val) && val !== '') val = Number(val);
      rec[f] = val;
    });
    records.push(rec);
  }
  return { records, has_more: d.has_more, page_token: d.query_context?.page_token };
}

// ─── 获取所有库存记录（两次 record-list） ──────────────
function fetchAllStock() {
  // 第一次：取前 200 条（默认排序）
  const r1 = larkCli(`base +record-list --base-token ${BASE_TOKEN} --table-id ${STOCK_TABLE} --limit 200`);
  const p1 = parseRecords(r1);
  let all = p1.records;

  // 第二次：取剩余记录（用 record-list 不带 limit，靠 has_more 判断）
  // 由于 record-list 不支持 offset，用 search 作为 fallback
  if (all.length >= 200) {
    try {
      const tmpFile = `.tmp-search-${Date.now()}.json`;
      fs.writeFileSync(tmpFile, JSON.stringify({ keyword: "|", search_fields: ["SPH_CYL"], limit: 50, offset: 200 }), 'utf-8');
      let r2;
      try {
        r2 = larkCli(`base +record-search --base-token ${BASE_TOKEN} --table-id ${STOCK_TABLE} --json @${tmpFile}`);
      } finally {
        try { fs.unlinkSync(tmpFile); } catch (_) {}
      }
      const p2 = parseRecords(r2);
      all = all.concat(p2.records);
    } catch (e) {
      // search 限流时只返回前 200 条
    }
  }

  const seen = new Set();
  return all.filter(r => { if (seen.has(r.record_id)) return false; seen.add(r.record_id); return true; });
}

// ─── 获取出库记录 ───────────────────────────────────────
function fetchDispatch() {
  const result = larkCli(`base +record-list --base-token ${BASE_TOKEN} --table-id ${DISPATCH_TABLE} --limit 200`);
  return parseRecords(result).records;
}

// ─── 库存缓存（序列号→record_id 映射） ─────────────────
let stockCache = {};  // seq => { record_id, sph, cyl, base, actual }
let cacheTime = 0;
const CACHE_TTL = 60000; // 1分钟

function refreshCache() {
  if (Date.now() - cacheTime < CACHE_TTL && Object.keys(stockCache).length > 0) return;
  const records = fetchAllStock();
  stockCache = {};
  records.forEach(r => {
    const seq = r['序列号'];
    if (seq != null && seq !== '') {
      const key = String(seq).padStart(3, '0');
      stockCache[key] = {
        record_id: r.record_id,
        sph: r.SPH, cyl: r.CYL,
        base: r['当前库存'], actual: r['实际库存']
      };
    }
  });
  cacheTime = Date.now();
}

// ─── HTTP 服务 ──────────────────────────────────────────
const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  const pathname = parsed.pathname;

  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.writeHead(200); res.end(); return; }

  if (pathname === '/' || pathname === '/index.html') {
    const html = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf-8');
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(html);
    return;
  }

  let result;
  try {
    if (pathname === '/api/stock' && req.method === 'GET') {
      result = { ok: true, records: fetchAllStock() };

    } else if (pathname === '/api/stock/by-seq' && req.method === 'GET') {
      // 按序列号查库存
      refreshCache();
      const seq = parsed.query.seq;
      const info = stockCache[seq];
      if (!info) { result = { ok: false, error: '序列号不存在: ' + seq }; }
      else { result = { ok: true, ...info }; }

    } else if (pathname === '/api/dispatch' && req.method === 'GET') {
      result = { ok: true, records: fetchDispatch() };

    } else if (pathname === '/api/stock/edit' && req.method === 'POST') {
      const body = await readBody(req);
      const { record_id, value } = JSON.parse(body);
      larkCliWithJson(
        `base +record-upsert --base-token ${BASE_TOKEN} --table-id ${STOCK_TABLE} --record-id ${record_id}`,
        { "当前库存": value }
      );
      cacheTime = 0;
      result = { ok: true };

    } else if (pathname === '/api/stock/add' && req.method === 'POST') {
      // 入库：当前库存 += quantity
      const body = await readBody(req);
      const { seq, quantity } = JSON.parse(body);
      refreshCache();
      const key = String(seq).padStart(3, '0');
      const info = stockCache[key];
      if (!info) { result = { ok: false, error: '序列号不存在: ' + key }; }
      else {
        const newTotal = (info.base || 0) + quantity;
        larkCliWithJson(
          `base +record-upsert --base-token ${BASE_TOKEN} --table-id ${STOCK_TABLE} --record-id ${info.record_id}`,
          { "当前库存": newTotal }
        );
        cacheTime = 0;
        result = { ok: true, seq: key, sph: info.sph, cyl: info.cyl, old: info.base, added: quantity, newTotal };
      }

    } else if (pathname === '/api/dispatch/create' && req.method === 'POST') {
      const body = await readBody(req);
      const { stock_record_id, quantity, date, model } = JSON.parse(body);
      larkCliWithJson(
        `base +record-upsert --base-token ${BASE_TOKEN} --table-id ${DISPATCH_TABLE}`,
        {
          "出库日期": date,
          "型号": model,
          "数量": quantity,
          "关联库存": [{ id: stock_record_id }]
        }
      );
      cacheTime = 0;
      result = { ok: true };

    } else if (pathname === '/api/dispatch/delete' && req.method === 'POST') {
      const body = await readBody(req);
      const { record_id } = JSON.parse(body);
      larkCli(`base +record-delete --base-token ${BASE_TOKEN} --table-id ${DISPATCH_TABLE} --record-id ${record_id} --yes`);
      cacheTime = 0;
      result = { ok: true };

    } else {
      res.writeHead(404);
      res.end('Not found');
      return;
    }
  } catch (err) {
    result = { ok: false, error: err.message };
  }

  res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(result));
});

function readBody(req) {
  return new Promise(resolve => {
    let data = '';
    req.on('data', c => data += c);
    req.on('end', () => resolve(data));
  });
}

server.listen(PORT, () => {
  console.log(`\n  Ultra 库存热力图工具`);
  console.log(`  http://localhost:${PORT}\n`);
});
