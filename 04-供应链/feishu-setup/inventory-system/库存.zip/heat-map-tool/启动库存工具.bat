@echo off
chcp 65001 >nul
title Ultra 车房库存管理

echo.
echo   Ultra 车房库存管理工具
echo   ========================
echo.

set "TOOL_DIR=%~dp0"
set "NODE_DIR=%TOOL_DIR%.node"

:: ─── 1. Node.js ─────────────────────────────
where node >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] Node.js 已安装
    goto :check_lark
)

if exist "%NODE_DIR%\node-v20.18.0-win-x64\node.exe" (
    set "PATH=%NODE_DIR%\node-v20.18.0-win-x64;%PATH%"
    echo [OK] Node.js 已就绪（便携版）
    goto :check_lark
)

echo [1/3] 首次运行，正在下载 Node.js（约30MB，请稍候）...
mkdir "%NODE_DIR%" 2>nul
curl -L --progress-bar -o "%NODE_DIR%\node.zip" "https://nodejs.org/dist/v20.18.0/node-v20.18.0-win-x64.zip"
if %errorlevel% neq 0 (
    echo 下载失败，请检查网络连接
    pause
    exit /b 1
)
echo [2/3] 正在解压...
powershell -Command "Expand-Archive -Path '%NODE_DIR%\node.zip' -DestinationPath '%NODE_DIR%' -Force"
del "%NODE_DIR%\node.zip"
set "PATH=%NODE_DIR%\node-v20.18.0-win-x64;%PATH%"
echo [OK] Node.js 已就绪

:: ─── 2. lark-cli ────────────────────────────
:check_lark
where lark-cli >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] lark-cli 已安装
    goto :start
)

echo [3/3] 正在安装 lark-cli...
call npm install -g @larksuite/cli
if %errorlevel% neq 0 (
    echo 安装 lark-cli 失败，请手动运行: npm install -g @larksuite/cli
    pause
    exit /b 1
)
echo [OK] lark-cli 已安装

:: ─── 3. 首次登录 ────────────────────────────
:start
echo.
echo 检查飞书登录状态...
lark-cli auth status >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo ========================================
    echo   首次使用需要登录飞书（只需一次）
    echo   请在弹出的浏览器中完成授权
    echo ========================================
    echo.
    lark-cli auth login --domain base
)

:: ─── 4. 启动服务 ────────────────────────────
echo.
echo   启动库存管理工具...
echo   浏览器将自动打开
echo   关闭此窗口停止服务
echo.

cd /d "%TOOL_DIR%"
timeout /t 2 /nobreak >nul
start "" "http://localhost:3456"
node server.js

pause
